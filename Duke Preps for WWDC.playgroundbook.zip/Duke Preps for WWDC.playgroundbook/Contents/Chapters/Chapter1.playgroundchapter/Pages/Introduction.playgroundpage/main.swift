/*:
 
 # Meet Duke 🧑🏽‍💻
 
 Duke is a passionate **iOS** 📱 developer, and a huge **Apple fan**. Duke is super hyped for **WWDC 2021**, and can't wait to get to know about all the fascinating new tech that will be unveiled this year!
 
 Let's follow Duke in his journey as he prepares himself for online WWDC 2021 event, by learning and implementing some algorithms and OS concepts.
 
 * Note: This playgroundbook looks better in Dark mode. ✌🏼
 
*/
